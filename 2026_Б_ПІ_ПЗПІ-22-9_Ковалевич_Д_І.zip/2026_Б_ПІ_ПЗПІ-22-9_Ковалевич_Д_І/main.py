from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from contextlib import asynccontextmanager

from core.config import settings
from api.routes import router
from services.steam_client import get_steam_client
from services.database import Database


@asynccontextmanager
async def lifespan(app: FastAPI):
    """Manage application lifespan events."""
    # Startup: Initialize services
    print(f"Starting {settings.app_name}...")
    
    # Pre-initialize the Steam client
    get_steam_client()
    
    # Connect to MongoDB
    try:
        await Database.connect()
    except Exception as e:
        print(f"Warning: Could not connect to MongoDB: {e}")
        print("The application will run without caching functionality")
    
    yield
    
    # Shutdown: cleanup
    print(f"Shutting down {settings.app_name}...")
    
    # Close Steam client
    steam_client = get_steam_client()
    await steam_client.close()
    
    # Disconnect from MongoDB
    await Database.disconnect()


# Create FastAPI application
app = FastAPI(
    title=settings.app_name,
    description="AI-powered semantic analysis of Steam game reviews",
    version="1.0.0",
    lifespan=lifespan
)

# Configure CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.cors_origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Include routers
app.include_router(router)


@app.get("/")
async def root():
    """Root endpoint with API information."""
    return {
        "name": settings.app_name,
        "version": "1.0.0",
        "description": "AI-powered semantic analysis of Steam game reviews",
        "features": [
            "Fetch Steam reviews via Steam API",
            "AI analysis with Gemini 1.5 Flash",
            "Extract bugs, wishes, and sentiment",
            "MongoDB caching for faster repeated queries"
        ],
        "endpoints": {
            "health": "GET /api/health",
            "analyze": "POST /api/analyze/{app_id}",
            "simple_analyze": "GET /api/analyze/{app_id}/simple",
            "history": "GET /api/analyze/{app_id}/history",
            "docs": "/docs",
            "redoc": "/redoc"
        }
    }


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(
        "main:app",
        host="0.0.0.0",
        port=8000,
        reload=settings.debug
    )