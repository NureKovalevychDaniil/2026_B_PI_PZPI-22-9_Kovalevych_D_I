import type { Config } from 'tailwindcss'

const config: Config = {
  content: [
    './src/pages/**/*.{js,ts,jsx,tsx,mdx}',
    './src/components/**/*.{js,ts,jsx,tsx,mdx}',
    './src/app/**/*.{js,ts,jsx,tsx,mdx}',
  ],
  theme: {
    extend: {
      colors: {
        steam: {
          bg: '#1b2838',
          card: '#2a475e',
          cardHover: '#3d6a8a',
          accent: '#66c0f4',
          accentDark: '#1a4a7a',
          text: '#c7d5e0',
          textMuted: '#8b9aaa',
          border: '#3a5a7a',
          success: '#4caf50',
          warning: '#ff9800',
          error: '#f44336',
          critical: '#d32f2f',
          high: '#f57c00',
          medium: '#ffa726',
          low: '#66bb6a',
        },
      },
      backgroundImage: {
        'gradient-radial': 'radial-gradient(var(--tw-gradient-stops))',
        'hero-pattern': 'linear-gradient(180deg, rgba(27,40,56,0.9) 0%, rgba(27,40,56,1) 100%)',
      },
    },
  },
  plugins: [],
}
export default config