import type { Metadata } from 'next'
import { Inter } from 'next/font/google'
import './globals.css'

const inter = Inter({ subsets: ['latin'] })

export const metadata: Metadata = {
  title: 'Steam Semantic Aggregator - AI Review Analysis',
  description: 'AI-powered semantic analysis of Steam game reviews using Gemini',
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="en">
      <body className={inter.className}>
        <div className="min-h-screen bg-steam-bg">
          <header className="border-b border-steam-border bg-steam-card/50 backdrop-blur-sm sticky top-0 z-50">
            <div className="container mx-auto px-4 py-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <svg
                    className="w-8 h-8 text-steam-accent"
                    fill="currentColor"
                    viewBox="0 0 24 24"
                  >
                    <path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-2 15l-5-5 1.41-1.41L10 14.17l7.59-7.59L19 8l-9 9z" />
                  </svg>
                  <h1 className="text-xl font-bold text-steam-text">
                    Steam Semantic Aggregator
                  </h1>
                </div>
                <nav className="flex items-center gap-4">
                  <a
                    href="/"
                    className="text-steam-text hover:text-steam-accent transition-colors"
                  >
                    Home
                  </a>
                  <a
                    href="https://github.com/your-repo"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-steam-text hover:text-steam-accent transition-colors"
                  >
                    GitHub
                  </a>
                </nav>
              </div>
            </div>
          </header>
          <main className="container mx-auto px-4 py-8">
            {children}
          </main>
          <footer className="border-t border-steam-border py-6 mt-12">
            <div className="container mx-auto px-4 text-center text-steam-textMuted text-sm">
              <p>
                Built with Next.js, FastAPI, and Google Gemini AI
              </p>
              <p className="mt-2">
                © 2024 Steam Semantic Aggregator. For educational purposes.
              </p>
            </div>
          </footer>
        </div>
      </body>
    </html>
  )
}