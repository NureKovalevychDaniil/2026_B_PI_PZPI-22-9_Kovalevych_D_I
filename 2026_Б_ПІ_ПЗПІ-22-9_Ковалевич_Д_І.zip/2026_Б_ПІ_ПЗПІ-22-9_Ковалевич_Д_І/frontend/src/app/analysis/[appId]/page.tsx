'use client';

import { useState, useEffect } from 'react';
import { useParams, useRouter } from 'next/navigation';
import {
  PieChart, Pie, Cell, BarChart, Bar, XAxis, YAxis, CartesianGrid,
  Tooltip, Legend, ResponsiveContainer
} from 'recharts';
import {
  ArrowLeft, Loader2, AlertCircle, Bug, Lightbulb, FileText,
  RefreshCw, CheckCircle, TrendingUp, MessageSquare
} from 'lucide-react';
import { AnalysisResult, BugReport, WishItem } from '@/types';
import { analyzeGame } from '@/lib/api';

const COLORS = {
  positive: '#4caf50',
  negative: '#f44336',
  critical: '#d32f2f',
  major: '#f57c00',
  minor: '#66bb6a',
  high: '#f57c00',
  medium: '#ffa726',
  low: '#66bb6a',
};

const SENTIMENT_COLORS = ['#4caf50', '#f44336'];

export default function AnalysisPage() {
  const params = useParams();
  const router = useRouter();
  const appId = params.appId as string;

  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [result, setResult] = useState<AnalysisResult | null>(null);
  const [gameName, setGameName] = useState<string>('');
  const [progress, setProgress] = useState(0);

  useEffect(() => {
    const fetchData = async () => {
      try {
        setLoading(true);
        setProgress(10);

        // Simulate progress
        const progressInterval = setInterval(() => {
          setProgress((prev) => Math.min(prev + 10, 80));
        }, 500);

        const response = await analyzeGame(parseInt(appId), 3);
        setProgress(90);

        if (response.success && response.data) {
          setResult(response.data);
          setGameName(`Game #${appId}`); // Could fetch from Steam API
        } else {
          setError(response.error || 'Analysis failed');
        }

        clearInterval(progressInterval);
        setProgress(100);
      } catch (err) {
        setError(err instanceof Error ? err.message : 'Failed to analyze game');
      } finally {
        setLoading(false);
      }
    };

    if (appId) {
      fetchData();
    }
  }, [appId]);

  const handleRetry = () => {
    setLoading(true);
    setError(null);
    setProgress(0);
    // Re-trigger the analysis
    window.location.reload();
  };

  const getSeverityBorderColor = (severity: string) => {
    switch (severity) {
      case 'critical': return 'border-l-steam-critical';
      case 'major': return 'border-l-steam-warning';
      case 'minor': return 'border-l-steam-success';
      default: return 'border-l-gray-500';
    }
  };

  const getPriorityBorderColor = (priority: string) => {
    switch (priority) {
      case 'high': return 'border-l-steam-high';
      case 'medium': return 'border-l-steam-medium';
      case 'low': return 'border-l-steam-low';
      default: return 'border-l-gray-500';
    }
  };

  const getSentimentBadgeColor = (sentiment: string) => {
    if (sentiment.includes('Positive')) return 'bg-green-500/20 text-green-400 border-green-500/30';
    if (sentiment.includes('Negative')) return 'bg-red-500/20 text-red-400 border-red-500/30';
    return 'bg-yellow-500/20 text-yellow-400 border-yellow-500/30';
  };

  if (loading) {
    return (
      <div className="max-w-4xl mx-auto">
        <div className="bg-steam-card rounded-xl p-12 text-center">
          <Loader2 className="w-16 h-16 text-steam-accent animate-spin mx-auto mb-6" />
          <h2 className="text-2xl font-bold text-steam-text mb-4">
            Analyzing Reviews...
          </h2>
          <p className="text-steam-textMuted mb-8">
            AI is processing hundreds of reviews for Game #{appId}
          </p>
          <div className="w-full max-w-md mx-auto bg-steam-bg rounded-full h-2 overflow-hidden">
            <div
              className="bg-steam-accent h-full transition-all duration-500"
              style={{ width: `${progress}%` }}
            />
          </div>
          <p className="text-steam-textMuted mt-4">{progress}% complete</p>
        </div>
      </div>
    );
  }

  if (error || !result) {
    return (
      <div className="max-w-4xl mx-auto">
        <button
          onClick={() => router.push('/')}
          className="flex items-center gap-2 text-steam-accent hover:text-steam-text mb-6 transition-colors"
        >
          <ArrowLeft className="w-5 h-5" />
          Back to Home
        </button>

        <div className="bg-steam-card rounded-xl p-12 text-center">
          <AlertCircle className="w-16 h-16 text-red-400 mx-auto mb-6" />
          <h2 className="text-2xl font-bold text-steam-text mb-4">
            Analysis Failed
          </h2>
          <p className="text-steam-textMuted mb-8">{error || 'Unknown error occurred'}</p>
          <button
            onClick={handleRetry}
            className="bg-steam-accent text-white font-semibold py-3 px-6 rounded-lg flex items-center gap-2 mx-auto hover:opacity-90 transition-opacity"
          >
            <RefreshCw className="w-5 h-5" />
            Try Again
          </button>
        </div>
      </div>
    );
  }

  const sentimentData = [
    { name: 'Positive', value: result.positive_reviews, color: COLORS.positive },
    { name: 'Negative', value: result.negative_reviews, color: COLORS.negative },
  ];

  const bugSeverityData = [
    { name: 'Critical', value: result.bugs.filter(b => b.severity === 'critical').length, color: COLORS.critical },
    { name: 'Major', value: result.bugs.filter(b => b.severity === 'major').length, color: COLORS.major },
    { name: 'Minor', value: result.bugs.filter(b => b.severity === 'minor').length, color: COLORS.minor },
  ];

  return (
    <div className="max-w-6xl mx-auto animate-fadeIn">
      {/* Header */}
      <div className="flex items-center gap-4 mb-8">
        <button
          onClick={() => router.push('/')}
          className="p-2 bg-steam-card rounded-lg hover:bg-steam-cardHover transition-colors"
        >
          <ArrowLeft className="w-5 h-5 text-steam-text" />
        </button>
        <div className="flex-1">
          <h1 className="text-2xl font-bold text-steam-text">{gameName}</h1>
          <p className="text-steam-textMuted">App ID: {appId}</p>
        </div>
        <span
          className={`px-4 py-2 rounded-full border font-semibold ${getSentimentBadgeColor(result.overall_sentiment)}`}
        >
          {result.overall_sentiment}
        </span>
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-8">
        <div className="bg-steam-card rounded-xl p-6 border border-steam-border">
          <div className="flex items-center gap-3 mb-2">
            <FileText className="w-5 h-5 text-steam-accent" />
            <span className="text-steam-textMuted text-sm">Reviews Analyzed</span>
          </div>
          <p className="text-3xl font-bold text-steam-text">{result.total_reviews_analyzed}</p>
        </div>

        <div className="bg-steam-card rounded-xl p-6 border border-steam-border">
          <div className="flex items-center gap-3 mb-2">
            <TrendingUp className="w-5 h-5 text-green-400" />
            <span className="text-steam-textMuted text-sm">Positive</span>
          </div>
          <p className="text-3xl font-bold text-green-400">{result.positive_reviews}</p>
        </div>

        <div className="bg-steam-card rounded-xl p-6 border border-steam-border">
          <div className="flex items-center gap-3 mb-2">
            <TrendingUp className="w-5 h-5 text-red-400 rotate-180" />
            <span className="text-steam-textMuted text-sm">Negative</span>
          </div>
          <p className="text-3xl font-bold text-red-400">{result.negative_reviews}</p>
        </div>

        <div className="bg-steam-card rounded-xl p-6 border border-steam-border">
          <div className="flex items-center gap-3 mb-2">
            <Bug className="w-5 h-5 text-orange-400" />
            <span className="text-steam-textMuted text-sm">Bugs Found</span>
          </div>
          <p className="text-3xl font-bold text-orange-400">{result.bugs.length}</p>
        </div>
      </div>

      {/* Charts Row */}
      <div className="grid md:grid-cols-2 gap-6 mb-8">
        {/* Sentiment Pie Chart */}
        <div className="bg-steam-card rounded-xl p-6 border border-steam-border">
          <h3 className="text-lg font-semibold text-steam-text mb-4 flex items-center gap-2">
            <MessageSquare className="w-5 h-5 text-steam-accent" />
            Sentiment Distribution
          </h3>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={sentimentData}
                  cx="50%"
                  cy="50%"
                  labelLine={false}
                  label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                  outerRadius={80}
                  fill="#8884d8"
                  dataKey="value"
                >
                  {sentimentData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip
                  contentStyle={{
                    backgroundColor: '#2a475e',
                    border: '1px solid #3a5a7a',
                    color: '#c7d5e0',
                  }}
                />
              </PieChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Bug Severity Bar Chart */}
        <div className="bg-steam-card rounded-xl p-6 border border-steam-border">
          <h3 className="text-lg font-semibold text-steam-text mb-4 flex items-center gap-2">
            <Bug className="w-5 h-5 text-steam-accent" />
            Bug Severity Distribution
          </h3>
          <div className="h-64">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={bugSeverityData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#3a5a7a" />
                <XAxis dataKey="name" stroke="#8b9aaa" />
                <YAxis stroke="#8b9aaa" />
                <Tooltip
                  contentStyle={{
                    backgroundColor: '#2a475e',
                    border: '1px solid #3a5a7a',
                    color: '#c7d5e0',
                  }}
                />
                <Bar dataKey="value" fill="#8884d8">
                  {bugSeverityData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      {/* Bugs Section */}
      <div className="mb-8">
        <h2 className="text-xl font-semibold text-steam-text mb-4 flex items-center gap-2">
          <Bug className="w-6 h-6 text-orange-400" />
          Bugs & Issues ({result.bugs.length})
        </h2>
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
          {result.bugs.slice(0, 12).map((bug, index) => (
            <div
              key={index}
              className={`bg-steam-card rounded-lg p-4 border border-steam-border border-l-4 ${getSeverityBorderColor(bug.severity)}`}
            >
              <div className="flex items-start justify-between mb-2">
                <span
                  className={`text-xs font-semibold px-2 py-1 rounded ${
                    bug.severity === 'critical'
                      ? 'bg-red-500/20 text-red-400'
                      : bug.severity === 'major'
                      ? 'bg-orange-500/20 text-orange-400'
                      : 'bg-green-500/20 text-green-400'
                  }`}
                >
                  {bug.severity.toUpperCase()}
                </span>
                <span className="text-steam-textMuted text-sm">
                  ×{bug.frequency}
                </span>
              </div>
              <p className="text-steam-text text-sm">{bug.description}</p>
            </div>
          ))}
        </div>
        {result.bugs.length > 12 && (
          <p className="text-steam-textMuted text-center mt-4">
            ...and {result.bugs.length - 12} more bugs
          </p>
        )}
      </div>

      {/* Wishes Section */}
      <div className="mb-8">
        <h2 className="text-xl font-semibold text-steam-text mb-4 flex items-center gap-2">
          <Lightbulb className="w-6 h-6 text-yellow-400" />
          Feature Requests ({result.wishes.length})
        </h2>
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
          {result.wishes.slice(0, 12).map((wish, index) => (
            <div
              key={index}
              className={`bg-steam-card rounded-lg p-4 border border-steam-border border-l-4 ${getPriorityBorderColor(wish.priority)}`}
            >
              <div className="flex items-start justify-between mb-2">
                <span
                  className={`text-xs font-semibold px-2 py-1 rounded ${
                    wish.priority === 'high'
                      ? 'bg-orange-500/20 text-orange-400'
                      : wish.priority === 'medium'
                      ? 'bg-yellow-500/20 text-yellow-400'
                      : 'bg-green-500/20 text-green-400'
                  }`}
                >
                  {wish.priority.toUpperCase()}
                </span>
                <span className="text-steam-textMuted text-sm">
                  ×{wish.frequency}
                </span>
              </div>
              <p className="text-steam-text text-sm">{wish.description}</p>
            </div>
          ))}
        </div>
        {result.wishes.length > 12 && (
          <p className="text-steam-textMuted text-center mt-4">
            ...and {result.wishes.length - 12} more wishes
          </p>
        )}
      </div>

      {/* AI Summary */}
      <div className="bg-steam-card rounded-xl p-6 border border-steam-border">
        <h2 className="text-xl font-semibold text-steam-text mb-4 flex items-center gap-2">
          <FileText className="w-6 h-6 text-steam-accent" />
          AI Summary
        </h2>
        <p className="text-steam-text leading-relaxed">{result.summary}</p>
        <div className="mt-4 pt-4 border-t border-steam-border">
          <p className="text-steam-textMuted text-sm">
            Analyzed on: {new Date(result.analyzed_at).toLocaleDateString('en-US', {
              year: 'numeric',
              month: 'long',
              day: 'numeric',
              hour: '2-digit',
              minute: '2-digit',
            })}
          </p>
        </div>
      </div>
    </div>
  );
}