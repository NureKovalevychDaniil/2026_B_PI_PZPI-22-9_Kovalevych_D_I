'use client';

import { useState, useEffect, useRef } from 'react';
import { useRouter } from 'next/navigation';
import { Search, Gamepad2, Sparkles, ArrowRight, Loader2, AlertCircle } from 'lucide-react';
import { GameSearchResult } from '@/types';
import { searchGames } from '@/lib/api';

export default function HomePage() {
  const router = useRouter();
  const [searchQuery, setSearchQuery] = useState('');
  const [searchResults, setSearchResults] = useState<GameSearchResult[]>([]);
  const [selectedGame, setSelectedGame] = useState<GameSearchResult | null>(null);
  const [isSearching, setIsSearching] = useState(false);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [showDropdown, setShowDropdown] = useState(false);
  const dropdownRef = useRef<HTMLDivElement>(null);

  // Debounced search
  useEffect(() => {
    if (!searchQuery.trim()) {
      setSearchResults([]);
      return;
    }

    const timer = setTimeout(async () => {
      setIsSearching(true);
      try {
        const results = await searchGames(searchQuery);
        setSearchResults(results);
        setShowDropdown(results.length > 0);
      } catch (err) {
        console.error('Search error:', err);
      } finally {
        setIsSearching(false);
      }
    }, 300);

    return () => clearTimeout(timer);
  }, [searchQuery]);

  // Close dropdown when clicking outside
  useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setShowDropdown(false);
      }
    }

    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const handleSelectGame = (game: GameSearchResult) => {
    setSelectedGame(game);
    setSearchQuery(game.name);
    setShowDropdown(false);
    setError(null);
  };

  const handleAnalyze = async () => {
    if (!selectedGame) {
      setError('Please select a game from the search results');
      return;
    }

    setIsAnalyzing(true);
    setError(null);

    try {
      router.push(`/analysis/${selectedGame.id}`);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to start analysis');
      setIsAnalyzing(false);
    }
  };

  const getSentimentColor = (sentiment: string) => {
    const colors: Record<string, string> = {
      'Overwhelmingly Positive': 'bg-green-500',
      'Very Positive': 'bg-green-600',
      'Mostly Positive': 'bg-green-700',
      'Mixed': 'bg-yellow-500',
      'Mostly Negative': 'bg-orange-600',
      'Negative': 'bg-red-600',
      'Overwhelmingly Negative': 'bg-red-700',
    };
    return colors[sentiment] || 'bg-gray-500';
  };

  return (
    <div className="max-w-4xl mx-auto">
      {/* Hero Section */}
      <div className="text-center mb-12 animate-fadeIn">
        <div className="flex justify-center mb-6">
          <div className="p-4 bg-steam-card rounded-full">
            <Gamepad2 className="w-16 h-16 text-steam-accent" />
          </div>
        </div>
        <h1 className="text-4xl font-bold text-steam-text mb-4">
          Steam Semantic Aggregator
        </h1>
        <p className="text-xl text-steam-textMuted max-w-2xl mx-auto">
          AI-powered analysis of Steam game reviews. Discover bugs, feature requests,
          and player sentiment with the power of Google Gemini.
        </p>
      </div>

      {/* Search Section */}
      <div className="bg-steam-card rounded-xl p-8 shadow-lg border border-steam-border mb-8">
        <h2 className="text-2xl font-semibold text-steam-text mb-6 flex items-center gap-2">
          <Search className="w-6 h-6 text-steam-accent" />
          Search for a Game
        </h2>

        <div className="relative" ref={dropdownRef}>
          <div className="relative">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-steam-textMuted" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Enter game name (e.g., Cyberpunk 2077)..."
              className="w-full bg-steam-bg border border-steam-border rounded-lg py-4 pl-12 pr-4 text-steam-text placeholder-steam-textMuted focus:outline-none focus:border-steam-accent transition-colors"
            />
            {isSearching && (
              <Loader2 className="absolute right-4 top-1/2 -translate-y-1/2 w-5 h-5 text-steam-accent animate-spin" />
            )}
          </div>

          {/* Search Dropdown */}
          {showDropdown && (
            <div className="absolute z-50 w-full mt-2 bg-steam-card border border-steam-border rounded-lg shadow-xl max-h-80 overflow-y-auto">
              {searchResults.map((game) => (
                <button
                  key={game.id}
                  onClick={() => handleSelectGame(game)}
                  className="w-full flex items-center gap-3 p-3 hover:bg-steam-cardHover transition-colors border-b border-steam-border last:border-b-0"
                >
                  <img
                    src={game.tiny_image}
                    alt={game.name}
                    className="w-12 h-12 rounded object-cover"
                    onError={(e) => {
                      (e.target as HTMLImageElement).src = 'https://via.placeholder.com/48x48/2a475e/66c0f4?text=?';
                    }}
                  />
                  <div className="flex-1 text-left">
                    <p className="text-steam-text font-medium">{game.name}</p>
                    <p className="text-steam-textMuted text-sm">App ID: {game.id}</p>
                  </div>
                  <ArrowRight className="w-5 h-5 text-steam-accent" />
                </button>
              ))}
            </div>
          )}
        </div>

        {/* Selected Game Display */}
        {selectedGame && (
          <div className="mt-6 p-4 bg-steam-bg rounded-lg border border-steam-border flex items-center gap-4">
            <img
              src={selectedGame.tiny_image}
              alt={selectedGame.name}
              className="w-16 h-16 rounded object-cover"
              onError={(e) => {
                (e.target as HTMLImageElement).src = 'https://via.placeholder.com/64x64/2a475e/66c0f4?text=?';
              }}
            />
            <div className="flex-1">
              <p className="text-steam-text font-semibold">{selectedGame.name}</p>
              <p className="text-steam-textMuted text-sm">App ID: {selectedGame.id}</p>
            </div>
            <button
              onClick={() => {
                setSelectedGame(null);
                setSearchQuery('');
              }}
              className="text-steam-textMuted hover:text-steam-text transition-colors"
            >
              Clear
            </button>
          </div>
        )}

        {/* Error Message */}
        {error && (
          <div className="mt-4 p-4 bg-red-500/10 border border-red-500/30 rounded-lg flex items-center gap-2 text-red-400">
            <AlertCircle className="w-5 h-5" />
            {error}
          </div>
        )}

        {/* Analyze Button */}
        <button
          onClick={handleAnalyze}
          disabled={!selectedGame || isAnalyzing}
          className="mt-6 w-full bg-gradient-to-r from-steam-accent to-steam-accentDark text-white font-semibold py-4 px-6 rounded-lg flex items-center justify-center gap-2 hover:opacity-90 transition-opacity disabled:opacity-50 disabled:cursor-not-allowed"
        >
          {isAnalyzing ? (
            <>
              <Loader2 className="w-5 h-5 animate-spin" />
              Starting Analysis...
            </>
          ) : (
            <>
              <Sparkles className="w-5 h-5" />
              Analyze Reviews
            </>
          )}
        </button>
      </div>

      {/* Features Section */}
      <div className="grid md:grid-cols-3 gap-6">
        <div className="bg-steam-card rounded-xl p-6 border border-steam-border">
          <div className="w-12 h-12 bg-steam-accent/20 rounded-lg flex items-center justify-center mb-4">
            <Search className="w-6 h-6 text-steam-accent" />
          </div>
          <h3 className="text-lg font-semibold text-steam-text mb-2">Smart Search</h3>
          <p className="text-steam-textMuted">
            Find any Steam game using our intelligent search powered by Steam Store API.
          </p>
        </div>

        <div className="bg-steam-card rounded-xl p-6 border border-steam-border">
          <div className="w-12 h-12 bg-steam-accent/20 rounded-lg flex items-center justify-center mb-4">
            <Sparkles className="w-6 h-6 text-steam-accent" />
          </div>
          <h3 className="text-lg font-semibold text-steam-text mb-2">AI Analysis</h3>
          <p className="text-steam-textMuted">
            Google Gemini analyzes hundreds of reviews to extract meaningful insights.
          </p>
        </div>

        <div className="bg-steam-card rounded-xl p-6 border border-steam-border">
          <div className="w-12 h-12 bg-steam-accent/20 rounded-lg flex items-center justify-center mb-4">
            <Gamepad2 className="w-6 h-6 text-steam-accent" />
          </div>
          <h3 className="text-lg font-semibold text-steam-text mb-2">Detailed Reports</h3>
          <p className="text-steam-textMuted">
            Get comprehensive reports with bugs, wishes, and sentiment analysis.
          </p>
        </div>
      </div>
    </div>
  );
}