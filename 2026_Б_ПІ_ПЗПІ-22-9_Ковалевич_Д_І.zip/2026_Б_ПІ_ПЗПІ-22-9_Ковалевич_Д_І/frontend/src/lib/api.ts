import { AnalysisResponse, GameSearchResult } from '@/types';

const API_BASE_URL = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:8000';

export async function analyzeGame(appId: number, pages: number = 3): Promise<AnalysisResponse> {
  const response = await fetch(`${API_BASE_URL}/api/analyze/${appId}?pages=${pages}`, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
  });

  if (!response.ok) {
    const errorData = await response.json().catch(() => ({}));
    throw new Error(errorData.detail || `Failed to analyze game: ${response.statusText}`);
  }

  return response.json();
}

export async function searchGames(query: string): Promise<GameSearchResult[]> {
  if (!query.trim()) return [];

  // Using Steam store search API through a proxy or direct call
  // Note: This may need CORS proxy in production
  try {
    const response = await fetch(
      `https://store.steampowered.com/api/storesearch?term=${encodeURIComponent(query)}&cc=us&l=english&count=10`
    );

    if (!response.ok) {
      throw new Error('Search failed');
    }

    const data = await response.json();
    return data.items || [];
  } catch (error) {
    console.error('Search error:', error);
    // Return mock results for development
    return getMockSearchResults(query);
  }
}

function getMockSearchResults(query: string): GameSearchResult[] {
  // Mock data for development when Steam API is not accessible
  const mockGames: GameSearchResult[] = [
    { id: 1091500, name: 'Cyberpunk 2077', tiny_image: 'https://cdn.cloudflare.steamstatic.com/steam/apps/1091500/capsule_sm_120.jpg' },
    { id: 730, name: 'Counter-Strike 2', tiny_image: 'https://cdn.cloudflare.steamstatic.com/steam/apps/730/capsule_sm_120.jpg' },
    { id: 570, name: 'Dota 2', tiny_image: 'https://cdn.cloudflare.steamstatic.com/steam/apps/570/capsule_sm_120.jpg' },
    { id: 271590, name: 'Grand Theft Auto V', tiny_image: 'https://cdn.cloudflare.steamstatic.com/steam/apps/271590/capsule_sm_120.jpg' },
    { id: 1174180, name: 'Red Dead Redemption 2', tiny_image: 'https://cdn.cloudflare.steamstatic.com/steam/apps/1174180/capsule_sm_120.jpg' },
    { id: 892970, name: 'Valheim', tiny_image: 'https://cdn.cloudflare.steamstatic.com/steam/apps/892970/capsule_sm_120.jpg' },
    { id: 1245620, name: 'ELDEN RING', tiny_image: 'https://cdn.cloudflare.steamstatic.com/steam/apps/1245620/capsule_sm_120.jpg' },
    { id: 413150, name: 'Stardew Valley', tiny_image: 'https://cdn.cloudflare.steamstatic.com/steam/apps/413150/capsule_sm_120.jpg' },
  ];

  if (!query.trim()) return [];

  return mockGames.filter(game =>
    game.name.toLowerCase().includes(query.toLowerCase())
  );
}

export async function getGameDetails(appId: number): Promise<{ name: string; image: string } | null> {
  try {
    const response = await fetch(
      `https://store.steampowered.com/api/appdetails?appids=${appId}`
    );

    if (!response.ok) {
      return null;
    }

    const data = await response.json();
    const gameData = data[appId];

    if (gameData && gameData.success) {
      return {
        name: gameData.data.name,
        image: gameData.data.header_image,
      };
    }

    return null;
  } catch (error) {
    console.error('Error fetching game details:', error);
    return null;
  }
}