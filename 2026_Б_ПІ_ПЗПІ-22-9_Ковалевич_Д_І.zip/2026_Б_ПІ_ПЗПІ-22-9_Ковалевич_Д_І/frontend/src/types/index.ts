export interface BugReport {
  description: string;
  severity: 'critical' | 'major' | 'minor';
  frequency: number;
}

export interface WishItem {
  description: string;
  priority: 'high' | 'medium' | 'low';
  frequency: number;
}

export interface AnalysisResult {
  app_id: number;
  total_reviews_analyzed: number;
  positive_reviews: number;
  negative_reviews: number;
  overall_sentiment: string;
  bugs: BugReport[];
  wishes: WishItem[];
  summary: string;
  analyzed_at: string;
}

export interface AnalysisResponse {
  success: boolean;
  data?: AnalysisResult;
  error?: string;
}

export interface GameSearchResult {
  id: number;
  name: string;
  tiny_image: string;
}

export interface SearchDropdownItem {
  id: number;
  name: string;
  image: string;
}