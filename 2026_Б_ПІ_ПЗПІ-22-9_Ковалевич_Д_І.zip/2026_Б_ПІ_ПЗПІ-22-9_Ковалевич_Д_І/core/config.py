from pydantic_settings import BaseSettings
from typing import List


class Settings(BaseSettings):
    """Application settings loaded from environment variables."""
    
    # API Keys
    gemini_api_key: str
    
    # MongoDB
    mongodb_url: str
    db_name: str = "steam_semantic_aggregator"
    
    # CORS
    cors_origins: List[str] = ["*"]
    
    # Application
    app_name: str = "Steam Semantic Aggregator"
    debug: bool = False
    
    class Config:
        env_file = ".env"
        case_sensitive = False


# Singleton instance
settings = Settings()