from pydantic import BaseModel, Field
from typing import List, Optional
from datetime import datetime


class ReviewRecommendation(BaseModel):
    """Schema for a single review recommendation from Steam."""
    recommendation_id: str
    author: dict
    language: str
    review: str
    timestamp_created: int
    timestamp_updated: int
    voted_up: bool
    votes_up: int
    votes_funny: int
    weighted_vote_score: float
    comment_count: int
    steam_purchase: bool
    received_for_free: bool
    written_during_early_access: bool


class SteamReviewsResponse(BaseModel):
    """Schema for the Steam API reviews response."""
    success: int
    query_summary: dict
    reviews: List[ReviewRecommendation]


class AnalysisRequest(BaseModel):
    """Request schema for analysis endpoint (path param app_id is used instead)."""
    pass


class BugReport(BaseModel):
    """Schema for a reported bug from analysis."""
    description: str
    severity: str = Field(..., description="Severity level: critical, major, minor")
    frequency: int = Field(default=0, description="Number of reviews mentioning this bug")


class WishItem(BaseModel):
    """Schema for a user wish/feature request from analysis."""
    description: str
    priority: str = Field(..., description="Priority level: high, medium, low")
    frequency: int = Field(default=0, description="Number of reviews mentioning this wish")


class AnalysisResult(BaseModel):
    """Schema for the AI analysis result."""
    app_id: int
    total_reviews_analyzed: int
    positive_reviews: int
    negative_reviews: int
    overall_sentiment: str = Field(..., description="positive, negative, or mixed")
    bugs: List[BugReport] = []
    wishes: List[WishItem] = []
    summary: Optional[str] = None
    analyzed_at: datetime = Field(default_factory=datetime.utcnow)


class AnalysisResponse(BaseModel):
    """Response schema for the analyze endpoint."""
    success: bool
    data: Optional[AnalysisResult] = None
    error: Optional[str] = None