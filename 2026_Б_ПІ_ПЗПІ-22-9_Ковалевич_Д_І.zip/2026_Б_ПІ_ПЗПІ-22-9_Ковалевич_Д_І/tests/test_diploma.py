"""
Comprehensive test suite for Steam Semantic Aggregator diploma work.
Tests cover all major components: SteamAPIClient, GeminiAIAnalyzer, Database, and integration.
All tests use mocking to ensure deterministic, repeatable results without external dependencies.
"""

import pytest
import asyncio
from unittest.mock import AsyncMock, MagicMock, patch
from datetime import datetime, timedelta, timezone

# Test data fixtures
@pytest.fixture
def mock_steam_response():
    """Mock response from Steam API with sample reviews."""
    return {
        "success": 1,
        "query_summary": {
            "num_reviews": 3,
            "review_score": 7,
            "review_score_desc": "Mostly Positive",
            "total_positive": 2,
            "total_negative": 1,
            "total_reviews": 3
        },
        "reviews": [
            {
                "recommendationid": "123456789",
                "author": {"steamid": "76561198000000001", "num_games_owned": 150},
                "language": "english",
                "review": "Game crashes frequently on startup. Very frustrating experience.",
                "timestamp_created": 1700000000,
                "timestamp_updated": 1700000000,
                "voted_up": False,
                "votes_up": 45,
                "votes_funny": 2,
                "weighted_vote_score": 0.75,
                "comment_count": 5,
                "steam_purchase": True,
                "received_for_free": False,
                "written_during_early_access": False
            },
            {
                "recommendationid": "123456790",
                "author": {"steamid": "76561198000000002", "num_games_owned": 80},
                "language": "english",
                "review": "Great graphics but poor optimization.",
                "timestamp_created": 1700000000,
                "timestamp_updated": 1700000000,
                "voted_up": True,
                "votes_up": 120,
                "votes_funny": 0,
                "weighted_vote_score": 0.85,
                "comment_count": 12,
                "steam_purchase": True,
                "received_for_free": False,
                "written_during_early_access": False
            },
            {
                "recommendationid": "123456791",
                "author": {"steamid": "76561198000000003", "num_games_owned": 200},
                "language": "english",
                "review": "FPS drops in crowded areas make the game unplayable.",
                "timestamp_created": 1700000000,
                "timestamp_updated": 1700000000,
                "voted_up": False,
                "votes_up": 78,
                "votes_funny": 1,
                "weighted_vote_score": 0.65,
                "comment_count": 8,
                "steam_purchase": True,
                "received_for_free": False,
                "written_during_early_access": False
            }
        ]
    }


@pytest.fixture
def mock_gemini_response():
    """Mock response from Gemini API with structured analysis."""
    response = MagicMock()
    response.text = '''{
    "overall_sentiment": "Mixed",
    "positive_reviews_count": 1,
    "negative_reviews_count": 2,
    "bugs": [
        {"description": "Game crashes frequently on startup", "severity": "critical", "frequency": 1},
        {"description": "FPS drops in crowded areas", "severity": "major", "frequency": 2},
        {"description": "Poor optimization overall", "severity": "major", "frequency": 1}
    ],
    "wishes": [
        {"description": "Performance optimization patches", "priority": "high", "frequency": 2},
        {"description": "Better stability fixes", "priority": "high", "frequency": 1}
    ],
    "summary": "Mixed reception with significant technical issues."
}'''
    return response


@pytest.fixture
def mock_cached_analysis():
    """Mock cached analysis result from MongoDB."""
    return {
        "_id": "507f1f77bcf86cd799439011",
        "app_id": 1091500,
        "total_reviews_analyzed": 3,
        "positive_reviews": 1,
        "negative_reviews": 2,
        "overall_sentiment": "Mixed",
        "bugs": [
            {"description": "Game crashes frequently on startup", "severity": "critical", "frequency": 1},
            {"description": "FPS drops in crowded areas", "severity": "major", "frequency": 2}
        ],
        "wishes": [
            {"description": "Performance optimization patches", "priority": "high", "frequency": 2}
        ],
        "summary": "Mixed reception with technical issues.",
        "analyzed_at": (datetime.now(timezone.utc) - timedelta(hours=2)).isoformat()
    }


# ============================================================================
# TEST 1: SteamAPIClient Tests
# ============================================================================

class TestSteamAPIClient:
    """Test suite for SteamAPIClient component."""

    @pytest.mark.asyncio
    async def test_fetch_reviews_success(self, mock_steam_response):
        """Test successful fetching of reviews from Steam API."""
        from services.steam_client import SteamAPIClient
        
        with patch('httpx.AsyncClient.get', new_callable=AsyncMock) as mock_get:
            mock_get.return_value = MagicMock(
                raise_for_status=lambda: None,
                json=lambda: mock_steam_response
            )
            
            client = SteamAPIClient()
            result = await client.fetch_reviews(1091500, limit=3)
            
            assert result is not None
            assert result["success"] == 1
            assert len(result["reviews"]) == 3
            assert result["query_summary"]["total_positive"] == 2
            assert result["query_summary"]["total_negative"] == 1
            
            await client.close()

    @pytest.mark.asyncio
    async def test_fetch_multiple_pages(self, mock_steam_response):
        """Test fetching multiple pages of reviews with pagination."""
        from services.steam_client import SteamAPIClient
        
        with patch('httpx.AsyncClient.get', new_callable=AsyncMock) as mock_get:
            mock_get.return_value = MagicMock(
                raise_for_status=lambda: None,
                json=lambda: mock_steam_response
            )
            
            client = SteamAPIClient()
            result = await client.fetch_multiple_pages(1091500, pages=2)
            
            assert isinstance(result, list)
            assert len(result) == 6  # 3 reviews per page * 2 pages
            
            await client.close()

    @pytest.mark.asyncio
    async def test_fetch_reviews_http_error(self):
        """Test handling of HTTP errors from Steam API."""
        from services.steam_client import SteamAPIClient
        import httpx
        
        with patch('httpx.AsyncClient.get', new_callable=AsyncMock) as mock_get:
            mock_get.side_effect = httpx.HTTPStatusError("404 Not Found", request=MagicMock(), response=MagicMock())
            
            client = SteamAPIClient()
            result = await client.fetch_reviews(1091500, limit=3)
            
            assert result is None
            
            await client.close()


# ============================================================================
# TEST 2: GeminiAIAnalyzer Tests
# ============================================================================

class TestGeminiAIAnalyzer:
    """Test suite for GeminiAIAnalyzer component."""

    @pytest.mark.asyncio
    async def test_analyze_reviews_success(self, mock_gemini_response):
        """Test successful analysis of reviews with AI."""
        from services.ai_analyzer import GeminiAIAnalyzer
        from models.schemas import AnalysisResult
        
        # Create a mock client with proper structure
        mock_client = MagicMock()
        mock_models = MagicMock()
        mock_models.generate_content = MagicMock(return_value=mock_gemini_response)
        mock_client.models = mock_models
        
        with patch('google.genai.Client', return_value=mock_client):
            analyzer = GeminiAIAnalyzer()
            mock_reviews = [
                {"review": "Game crashes frequently on startup", "voted_up": False},
                {"review": "Great graphics but poor optimization", "voted_up": True},
                {"review": "FPS drops in crowded areas", "voted_up": False}
            ]
            
            result = await analyzer.analyze_reviews(1091500, mock_reviews)
            
            assert result is not None
            assert isinstance(result, AnalysisResult)
            assert result.app_id == 1091500
            assert result.total_reviews_analyzed == 3
            assert result.positive_reviews == 1
            assert result.negative_reviews == 2
            assert result.overall_sentiment == "Mixed"
            assert len(result.bugs) == 3
            assert len(result.wishes) == 2

    @pytest.mark.asyncio
    async def test_analyze_reviews_empty_input(self):
        """Test analysis with empty review list."""
        from services.ai_analyzer import GeminiAIAnalyzer
        
        # Create a mock client
        mock_client = MagicMock()
        mock_models = MagicMock()
        mock_models.generate_content = MagicMock()
        mock_client.models = mock_models
        
        with patch('google.genai.Client', return_value=mock_client):
            analyzer = GeminiAIAnalyzer()
            result = await analyzer.analyze_reviews(1091500, [])
            
            assert result is None

    @pytest.mark.asyncio
    async def test_merge_similar_items(self):
        """Test deduplication algorithm for similar bug descriptions."""
        from services.ai_analyzer import GeminiAIAnalyzer
        
        analyzer = GeminiAIAnalyzer()
        items = [
            {"description": "Game crashes on startup", "frequency": 3, "severity": "critical"},
            {"description": "Game crashes on loading screen", "frequency": 2, "severity": "critical"},
            {"description": "Game crashes on startup", "frequency": 5, "severity": "critical"}
        ]
        
        merged = analyzer._merge_similar_items(items, "description")
        
        # First and third should be merged (same first 4 words)
        assert len(merged) == 2
        assert merged[0]["frequency"] == 8  # 3 + 5
        assert merged[1]["frequency"] == 2

    @pytest.mark.asyncio
    async def test_analyze_in_batches(self, mock_gemini_response):
        """Test batch processing of large review sets."""
        # Create a mock client with proper structure
        mock_client = MagicMock()
        mock_models = MagicMock()
        mock_models.generate_content = MagicMock(return_value=mock_gemini_response)
        mock_client.models = mock_models
        
        with patch('google.genai.Client', return_value=mock_client):
            from services.ai_analyzer import GeminiAIAnalyzer
            
            analyzer = GeminiAIAnalyzer()
            
            # Create 5 reviews to test batching
            large_review_set = [
                {"review": f"Review {i} text", "voted_up": i % 2 == 0}
                for i in range(5)
            ]
            
            result = await analyzer.analyze_reviews(1091500, large_review_set)
            
            assert result is not None
            assert result.total_reviews_analyzed == 5


# ============================================================================
# TEST 3: Database Tests
# ============================================================================

class TestDatabase:
    """Test suite for Database component."""

    @pytest.mark.asyncio
    async def test_get_cached_analysis_found(self, mock_cached_analysis):
        """Test retrieving cached analysis when it exists and is fresh."""
        from services.database import Database
        
        with patch.object(Database, 'database') as mock_db:
            mock_collection = AsyncMock()
            mock_collection.find_one = AsyncMock(return_value=mock_cached_analysis)
            mock_db.analysis_results = mock_collection
            
            result = await Database.get_cached_analysis(1091500, max_age_hours=24)
            
            assert result is not None
            assert result["app_id"] == 1091500
            assert result["overall_sentiment"] == "Mixed"
            mock_collection.find_one.assert_awaited_once()

    @pytest.mark.asyncio
    async def test_get_cached_analysis_not_found(self):
        """Test when no cached analysis exists."""
        from services.database import Database
        
        with patch.object(Database, 'database') as mock_db:
            mock_collection = AsyncMock()
            mock_collection.find_one = AsyncMock(return_value=None)
            mock_db.analysis_results = mock_collection
            
            result = await Database.get_cached_analysis(1091500, max_age_hours=24)
            
            assert result is None

    @pytest.mark.asyncio
    async def test_save_analysis_result(self):
        """Test saving analysis result to database."""
        from services.database import Database
        
        test_data = {
            "app_id": 1091500,
            "overall_sentiment": "Mixed",
            "bugs": [{"description": "Test bug", "severity": "major", "frequency": 1}]
        }
        
        with patch.object(Database, 'database') as mock_db:
            mock_collection = AsyncMock()
            mock_collection.insert_one = AsyncMock(return_value=MagicMock(inserted_id="507f1f77bcf86cd799439011"))
            mock_db.analysis_results = mock_collection
            
            result_id = await Database.save_analysis_result(test_data)
            
            assert result_id == "507f1f77bcf86cd799439011"
            mock_collection.insert_one.assert_awaited_once_with(test_data)


# ============================================================================
# TEST 4: Schema Validation Tests
# ============================================================================

class TestSchemas:
    """Tests for Pydantic schema validation."""

    def test_analysis_result_schema(self):
        """Test AnalysisResult schema validation."""
        from models.schemas import AnalysisResult, BugReport, WishItem
        
        result = AnalysisResult(
            app_id=1091500,
            total_reviews_analyzed=100,
            positive_reviews=60,
            negative_reviews=40,
            overall_sentiment="Mixed",
            bugs=[
                BugReport(description="Crash on startup", severity="critical", frequency=5)
            ],
            wishes=[
                WishItem(description="Better optimization", priority="high", frequency=10)
            ],
            summary="Overall positive with some issues."
        )
        
        assert result.app_id == 1091500
        assert len(result.bugs) == 1
        assert result.bugs[0].severity == "critical"
        assert len(result.wishes) == 1
        assert result.wishes[0].priority == "high"

    def test_bug_report_validation(self):
        """Test BugReport schema validation."""
        from models.schemas import BugReport
        
        bug = BugReport(
            description="FPS drops in cities",
            severity="major",
            frequency=15
        )
        
        assert bug.description == "FPS drops in cities"
        assert bug.severity == "major"
        assert bug.frequency == 15


# ============================================================================
# Run tests with verbose output for screenshots
# ============================================================================

if __name__ == "__main__":
    pytest.main([
        __file__,
        "-v",
        "--tb=short",
        "-s",
        "--color=yes"
    ])