from fastapi import APIRouter, HTTPException, Depends, Query
from typing import Optional

from models.schemas import AnalysisResponse, AnalysisResult
from services.steam_client import get_steam_client, SteamAPIClient
from services.ai_analyzer import get_ai_analyzer, GeminiAIAnalyzer
from services.database import Database, get_database

router = APIRouter(prefix="/api", tags=["analysis"])


@router.get("/health")
async def health_check():
    """Health check endpoint."""
    return {"status": "healthy", "service": "steam-semantic-aggregator"}


@router.post("/analyze/{app_id}", response_model=AnalysisResponse)
async def analyze_app_reviews(
    app_id: int,
    pages: Optional[int] = Query(default=3, le=10, ge=1),
    use_cache: Optional[bool] = Query(default=True, description="Use cached results if available"),
    cache_hours: Optional[int] = Query(default=24, le=168, ge=1, description="Cache validity in hours"),
    steam_client: SteamAPIClient = Depends(get_steam_client),
    ai_analyzer: GeminiAIAnalyzer = Depends(get_ai_analyzer),
    db: Database = Depends(get_database)
) -> AnalysisResponse:
    """
    Analyze Steam reviews for a specific app.
    
    This endpoint fetches reviews from Steam and uses AI to analyze them,
    extracting bugs, feature requests, and overall sentiment.
    Results are cached in MongoDB for the specified duration.
    
    Args:
        app_id: Steam App ID to analyze
        pages: Number of review pages to fetch (default: 3, max: 10)
        use_cache: Use cached results if available (default: True)
        cache_hours: Cache validity duration in hours (default: 24, max: 168)
        steam_client: Injected Steam API client
        ai_analyzer: Injected AI analyzer
        db: Injected database service
        
    Returns:
        AnalysisResponse with structured analysis results
    """
    try:
        # Check for cached result first (if caching is enabled)
        if use_cache:
            cached_result = await db.get_cached_analysis(app_id, cache_hours)
            if cached_result:
                print(f"Using cached analysis for app {app_id}")
                # Remove MongoDB internal fields
                cached_result.pop("_id", None)
                return AnalysisResponse(
                    success=True,
                    data=cached_result,
                    error=None
                )
        
        # Fetch reviews from Steam
        reviews = await steam_client.fetch_multiple_pages(
            app_id=app_id,
            pages=pages
        )
        
        if not reviews:
            raise HTTPException(
                status_code=404,
                detail=f"No reviews found for app ID {app_id} or app doesn't exist"
            )
        
        # Analyze reviews with AI
        analysis_result = await ai_analyzer.analyze_reviews(
            app_id=app_id,
            reviews=reviews
        )
        
        if not analysis_result:
            raise HTTPException(
                status_code=500,
                detail="Failed to analyze reviews with AI"
            )
        
        # Save to database for caching
        try:
            # Convert to dict for MongoDB
            result_dict = analysis_result.model_dump()
            await db.save_analysis_result(result_dict)
            print(f"Saved analysis for app {app_id} to database")
        except Exception as e:
            print(f"Warning: Could not save to database: {e}")
        
        return AnalysisResponse(
            success=True,
            data=analysis_result,
            error=None
        )
        
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(
            status_code=500,
            detail=f"Internal server error: {str(e)}"
        )


@router.get("/analyze/{app_id}/simple", response_model=AnalysisResponse)
async def simple_analyze_app_reviews(
    app_id: int,
    steam_client: SteamAPIClient = Depends(get_steam_client)
) -> AnalysisResponse:
    """
    Simple analysis endpoint that returns basic review statistics without AI analysis.
    Useful for testing or when AI analysis is not needed.
    
    Args:
        app_id: Steam App ID to analyze
        steam_client: Injected Steam API client
        
    Returns:
        AnalysisResponse with basic statistics
    """
    try:
        # Fetch a single page of reviews
        reviews = await steam_client.fetch_reviews(app_id=app_id, limit=20)
        
        if not reviews or not reviews.get("success"):
            raise HTTPException(
                status_code=404,
                detail=f"No reviews found for app ID {app_id} or app doesn't exist"
            )
        
        review_list = reviews.get("reviews", [])
        positive_count = sum(1 for r in review_list if r.get("voted_up", False))
        negative_count = len(review_list) - positive_count
        
        # Determine sentiment
        if len(review_list) == 0:
            sentiment = "mixed"
        elif positive_count / len(review_list) > 0.7:
            sentiment = "positive"
        elif positive_count / len(review_list) < 0.3:
            sentiment = "negative"
        else:
            sentiment = "mixed"
        
        # Create a simple analysis result
        from datetime import datetime
        result = AnalysisResult(
            app_id=app_id,
            total_reviews_analyzed=len(review_list),
            positive_reviews=positive_count,
            negative_reviews=negative_count,
            overall_sentiment=sentiment,
            bugs=[],
            wishes=[],
            summary=f"Basic analysis of {len(review_list)} reviews. {positive_count} positive, {negative_count} negative."
        )
        
        return AnalysisResponse(
            success=True,
            data=result
        )
        
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(
            status_code=500,
            detail=f"Internal server error: {str(e)}"
        )


@router.get("/analyze/{app_id}/history", response_model=list)
async def get_analysis_history(
    app_id: int,
    limit: Optional[int] = Query(default=10, le=50, ge=1),
    db: Database = Depends(get_database)
) -> list:
    """
    Get analysis history for a specific app.
    
    Args:
        app_id: Steam App ID
        limit: Maximum number of results to return (default: 10, max: 50)
        db: Injected database service
        
    Returns:
        List of historical analysis results
    """
    try:
        history = await db.get_analysis_history(app_id, limit)
        
        # Remove MongoDB internal fields
        for item in history:
            item.pop("_id", None)
        
        return history
        
    except Exception as e:
        raise HTTPException(
            status_code=500,
            detail=f"Error fetching history: {str(e)}"
        )