import httpx
from typing import List, Optional
from core.config import settings


class SteamAPIClient:
    """Async client for interacting with Steam API."""
    
    BASE_URL = "https://store.steampowered.com/appreviews"
    
    def __init__(self):
        self.client = httpx.AsyncClient(
            timeout=30.0,
            headers={
                "User-Agent": "SteamSemanticAggregator/1.0"
            }
        )
    
    async def fetch_reviews(
        self, 
        app_id: int, 
        language: str = "all",
        purchase_type: str = "all",
        limit: int = 100,
        cursor: str = "*"
    ) -> Optional[dict]:
        """
        Fetch reviews for a specific Steam app.
        
        Args:
            app_id: Steam App ID
            language: Language filter (default: "all")
            purchase_type: Purchase type filter - 'all', 'steam', 'non_steam' (default: "all")
            limit: Number of reviews to fetch per request (max 100)
            cursor: Pagination cursor (default: "*" for first page)
            
        Returns:
            Dictionary containing reviews data or None if request fails
        """
        params = {
            "json": 1,
            "language": language,
            "purchase_type": purchase_type,
            "num_per_page": min(limit, 100),
            "cursor": cursor
        }
        
        try:
            response = await self.client.get(
                f"{self.BASE_URL}/{app_id}",
                params=params
            )
            response.raise_for_status()
            data = response.json()
            return data
        except httpx.HTTPError as e:
            print(f"HTTP error while fetching reviews for app {app_id}: {e}")
            return None
        except Exception as e:
            print(f"Error fetching reviews for app {app_id}: {e}")
            return None
    
    async def fetch_multiple_pages(
        self,
        app_id: int,
        pages: int = 3,
        **kwargs
    ) -> List[dict]:
        """
        Fetch multiple pages of reviews for more comprehensive analysis.
        
        Args:
            app_id: Steam App ID
            pages: Number of pages to fetch
            **kwargs: Additional arguments passed to fetch_reviews
            
        Returns:
            List of review dictionaries from all pages
        """
        all_reviews = []
        cursor = "*"
        
        for _ in range(pages):
            data = await self.fetch_reviews(app_id, cursor=cursor, **kwargs)
            if not data or not data.get("success"):
                break
            
            reviews = data.get("reviews", [])
            all_reviews.extend(reviews)
            
            # Get next cursor
            cursor = data.get("cursor", "")
            if cursor == "*":
                break
        
        return all_reviews
    
    async def close(self):
        """Close the HTTP client."""
        await self.client.aclose()


# Singleton instance for dependency injection
_steam_client: Optional[SteamAPIClient] = None


def get_steam_client() -> SteamAPIClient:
    """Dependency injection for Steam API client."""
    global _steam_client
    if _steam_client is None:
        _steam_client = SteamAPIClient()
    return _steam_client