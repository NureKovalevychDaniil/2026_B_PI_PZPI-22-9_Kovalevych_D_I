from motor.motor_asyncio import AsyncIOMotorClient, AsyncIOMotorDatabase
from typing import Optional
from datetime import datetime, timedelta
from core.config import settings


class Database:
    """Async MongoDB database service with caching support."""
    
    client: Optional[AsyncIOMotorClient] = None
    database: Optional[AsyncIOMotorDatabase] = None
    
    @classmethod
    async def connect(cls):
        """Connect to MongoDB Atlas."""
        if cls.client is None:
            cls.client = AsyncIOMotorClient(settings.mongodb_url)
            cls.database = cls.client[settings.db_name]
            
            # Test connection
            await cls.client.admin.command('ping')
            print(f"Connected to MongoDB: {settings.db_name}")
            
            # Create indexes for better query performance
            await cls.database.analysis_results.create_index("app_id")
            await cls.database.analysis_results.create_index("analyzed_at")
    
    @classmethod
    async def disconnect(cls):
        """Disconnect from MongoDB."""
        if cls.client:
            cls.client.close()
            cls.client = None
            cls.database = None
            print("Disconnected from MongoDB")
    
    @classmethod
    async def get_cached_analysis(
        cls, 
        app_id: int, 
        max_age_hours: int = 24
    ) -> Optional[dict]:
        """
        Get cached analysis result if it exists and is fresh enough.
        
        Args:
            app_id: Steam App ID
            max_age_hours: Maximum age of cached result in hours (default: 24)
            
        Returns:
            Cached analysis document or None if not found or expired
        """
        if cls.database is None:
            return None
        
        cutoff_time = datetime.utcnow() - timedelta(hours=max_age_hours)
        
        result = await cls.database.analysis_results.find_one(
            {
                "app_id": app_id,
                "analyzed_at": {"$gte": cutoff_time}
            },
            sort=[("analyzed_at", -1)]
        )
        
        return result
    
    @classmethod
    async def save_analysis_result(cls, analysis_data: dict) -> str:
        """
        Save analysis result to database.
        
        Args:
            analysis_data: Analysis result data to save
            
        Returns:
            Inserted document ID
        """
        if cls.database is None:
            raise RuntimeError("Database not connected")
        
        result = await cls.database.analysis_results.insert_one(analysis_data)
        return str(result.inserted_id)
    
    @classmethod
    async def get_analysis_history(
        cls, 
        app_id: int, 
        limit: int = 10
    ) -> list:
        """
        Get analysis history for a specific app.
        
        Args:
            app_id: Steam App ID
            limit: Maximum number of results to return
            
        Returns:
            List of analysis documents
        """
        if cls.database is None:
            return []
        
        cursor = cls.database.analysis_results.find(
            {"app_id": app_id}
        ).sort("analyzed_at", -1).limit(limit)
        
        return await cursor.to_list(length=limit)
    
    @classmethod
    async def get_db(cls) -> AsyncIOMotorDatabase:
        """Get database instance, connecting if necessary."""
        if cls.database is None:
            await cls.connect()
        return cls.database


# Dependency injection
async def get_database() -> Database:
    """Dependency injection for database."""
    if Database.database is None:
        await Database.connect()
    return Database