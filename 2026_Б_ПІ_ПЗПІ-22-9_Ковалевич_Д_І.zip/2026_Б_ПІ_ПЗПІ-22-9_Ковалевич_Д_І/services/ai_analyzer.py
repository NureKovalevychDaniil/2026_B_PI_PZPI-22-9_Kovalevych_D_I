from google import genai
import json
from typing import List, Optional, Dict, Any
from core.config import settings
from models.schemas import AnalysisResult, BugReport, WishItem


class GeminiAIAnalyzer:
    """AI analyzer using Google's Gemini API for semantic analysis of reviews."""
    
    def __init__(self):
        """Initialize the Gemini API client."""
        # Using the new google.genai client
        self.client = genai.Client(api_key=settings.gemini_api_key)
        # Using Gemini Flash Lite for fast, cost-effective analysis
        # Using latest version for best availability
        self.model_name = "gemini-flash-lite-latest"
    
    def _build_prompt(self, reviews: List[str]) -> str:
        """
        Build the prompt for the AI model.
        
        Args:
            reviews: List of review texts to analyze
            
        Returns:
            Formatted prompt string
        """
        reviews_text = "\n---\n".join([f"Review {i+1}:\n{review}" for i, review in enumerate(reviews)])
        
        prompt = f"""Analyze the following Steam game reviews in detail and extract comprehensive structured information.

Return your response as a valid JSON object with the following structure:

{{
    "overall_sentiment": "Overwhelmingly Positive|Very Positive|Mostly Positive|Mixed|Mostly Negative|Negative|Overwhelmingly Negative",
    "positive_reviews_count": <number>,
    "negative_reviews_count": <number>,
    "bugs": [
        {{"description": "detailed bug description", "severity": "critical|major|minor", "frequency": <number>}}
    ],
    "wishes": [
        {{"description": "detailed feature request", "priority": "high|medium|low", "frequency": <number>}}
    ],
    "summary": "comprehensive summary of overall feedback (3-5 sentences)"
}}

IMPORTANT GUIDELINES:

1. SENTIMENT ANALYSIS:
   - Use the full Steam sentiment scale: Overwhelmingly Positive (>95% positive), Very Positive (85-95%), Mostly Positive (70-85%), Mixed (40-70%), Mostly Negative (20-40%), Negative (5-20%), Overwhelmingly Negative (<5%)
   - Base your analysis on both the explicit thumbs up/down and the review content tone

2. BUGS/ISSUES - BE EXTREMELY THOROUGH:
   - List EVERY unique bug or technical issue mentioned across reviews
   - Do NOT group similar bugs together - list each distinct issue separately
   - Include: crashes, performance issues, graphical glitches, audio problems, UI bugs, save issues, multiplayer problems, compatibility issues, etc.
   - For each bug, estimate how many reviews mention it (frequency)
   - Assign severity: critical (game-breaking), major (significantly affects gameplay), minor (cosmetic or rare)

3. WISHES/FEATURE REQUESTS - BE COMPREHENSIVE:
   - List EVERY unique feature request or suggestion mentioned
   - Do NOT group similar wishes - list each distinct request separately
   - Include: gameplay improvements, new features, quality of life changes, content requests, modding support, etc.
   - For each wish, estimate how many reviews mention it (frequency)
   - Assign priority based on how often and how strongly it's mentioned

4. SUMMARY:
   - Write a comprehensive 3-5 sentence summary covering:
     * Overall player reception
     * Main strengths praised by players
     * Main criticisms or concerns
     * Technical state of the game

Reviews to analyze:
{reviews_text}

Respond ONLY with the JSON object, no additional text. Make sure to be as detailed and comprehensive as possible."""
        
        return prompt
    
    async def analyze_reviews(
        self, 
        app_id: int, 
        reviews: List[Dict[str, Any]]
    ) -> Optional[AnalysisResult]:
        """
        Analyze a list of Steam reviews using Gemini AI.
        Supports batch processing for large review sets.
        
        Args:
            app_id: Steam App ID
            reviews: List of review dictionaries from Steam API
            
        Returns:
            AnalysisResult object with structured analysis or None if analysis fails
        """
        if not reviews:
            return None
        
        # Extract review texts and determine sentiment from voted_up
        review_texts = []
        positive_count = 0
        negative_count = 0
        
        for review in reviews:
            review_text = review.get("review", "")
            if review_text:
                review_texts.append(review_text)
                if review.get("voted_up", False):
                    positive_count += 1
                else:
                    negative_count += 1
        
        if not review_texts:
            return None
        
        # For very large sets, we'll process in batches and merge results
        # But for now, let's handle up to 100 reviews in a single request
        # Gemini Flash Lite can handle this amount
        max_reviews_single = 100
        
        try:
            if len(review_texts) <= max_reviews_single:
                # Single request processing
                return await self._analyze_batch(app_id, review_texts, positive_count, negative_count)
            else:
                # Batch processing for large review sets
                return await self._analyze_in_batches(app_id, review_texts, positive_count, negative_count)
                
        except json.JSONDecodeError as e:
            print(f"Failed to parse AI response as JSON: {e}")
            return None
        except Exception as e:
            print(f"Error analyzing reviews with AI: {e}")
            return None
    
    async def _analyze_batch(
        self,
        app_id: int,
        review_texts: List[str],
        positive_count: int,
        negative_count: int
    ) -> Optional[AnalysisResult]:
        """Analyze a single batch of reviews with retry logic."""
        # Build and send prompt
        prompt = self._build_prompt(review_texts)
        
        # Retry logic for API availability issues
        max_retries = 3
        retry_delay = 5  # seconds
        
        response = None
        for attempt in range(max_retries):
            try:
                response = self.client.models.generate_content(
                    model=self.model_name,
                    contents=prompt
                )
                break
            except Exception as e:
                error_str = str(e)
                if "UNAVAILABLE" in error_str or "503" in error_str:
                    if attempt < max_retries - 1:
                        print(f"API unavailable, retrying in {retry_delay}s... (attempt {attempt + 1}/{max_retries})")
                        import time
                        time.sleep(retry_delay)
                        retry_delay *= 2  # Exponential backoff
                    else:
                        raise
                else:
                    raise
        
        # Parse response
        response_text = response.text.strip()
        
        # Remove markdown code blocks if present
        if response_text.startswith("```json"):
            response_text = response_text[7:]
        if response_text.endswith("```"):
            response_text = response_text[:-3]
        if response_text.startswith("```"):
            response_text = response_text[3:]
        if response_text.endswith("```"):
            response_text = response_text[:-3]
        
        response_text = response_text.strip()
        
        # Parse JSON
        analysis_data = json.loads(response_text)
        
        # Build AnalysisResult
        bugs = [
            BugReport(
                description=bug.get("description", ""),
                severity=bug.get("severity", "minor"),
                frequency=bug.get("frequency", 0)
            )
            for bug in analysis_data.get("bugs", [])
        ]
        
        wishes = [
            WishItem(
                description=wish.get("description", ""),
                priority=wish.get("priority", "low"),
                frequency=wish.get("frequency", 0)
            )
            for wish in analysis_data.get("wishes", [])
        ]
        
        result = AnalysisResult(
            app_id=app_id,
            total_reviews_analyzed=len(review_texts),
            positive_reviews=positive_count,
            negative_reviews=negative_count,
            overall_sentiment=analysis_data.get("overall_sentiment", "mixed"),
            bugs=bugs,
            wishes=wishes,
            summary=analysis_data.get("summary")
        )
        
        return result
    
    async def _analyze_in_batches(
        self,
        app_id: int,
        review_texts: List[str],
        positive_count: int,
        negative_count: int
    ) -> Optional[AnalysisResult]:
        """Analyze reviews in multiple batches and merge results."""
        batch_size = 80  # Safe size for each request
        all_bugs = []
        all_wishes = []
        all_summaries = []
        total_analyzed = 0
        
        for i in range(0, len(review_texts), batch_size):
            batch = review_texts[i:i + batch_size]
            print(f"Processing batch {i // batch_size + 1} with {len(batch)} reviews...")
            
            # Build prompt for this batch
            prompt = self._build_batch_prompt(batch)
            
            # Retry logic for batch processing
            max_retries = 3
            retry_delay = 5
            response = None
            
            for attempt in range(max_retries):
                try:
                    response = self.client.models.generate_content(
                        model=self.model_name,
                        contents=prompt
                    )
                    break
                except Exception as e:
                    error_str = str(e)
                    if "UNAVAILABLE" in error_str or "503" in error_str:
                        if attempt < max_retries - 1:
                            print(f"  API unavailable, retrying in {retry_delay}s... (attempt {attempt + 1}/{max_retries})")
                            import time
                            time.sleep(retry_delay)
                            retry_delay *= 2
                        else:
                            print(f"  Failed after {max_retries} attempts")
                            continue
                    else:
                        raise
            
            response_text = response.text.strip()
            
            # Remove markdown code blocks if present
            if response_text.startswith("```json"):
                response_text = response_text[7:]
            if response_text.endswith("```"):
                response_text = response_text[:-3]
            if response_text.startswith("```"):
                response_text = response_text[3:]
            if response_text.endswith("```"):
                response_text = response_text[:-3]
            
            response_text = response_text.strip()
            
            try:
                batch_data = json.loads(response_text)
                
                # Collect bugs and wishes
                all_bugs.extend(batch_data.get("bugs", []))
                all_wishes.extend(batch_data.get("wishes", []))
                if batch_data.get("summary"):
                    all_summaries.append(batch_data.get("summary"))
                
                total_analyzed += len(batch)
            except json.JSONDecodeError as e:
                print(f"Failed to parse batch {i // batch_size + 1}: {e}")
                continue
        
        # Merge and deduplicate results
        # For bugs - group by similar description
        merged_bugs = self._merge_similar_items(all_bugs, "description")
        merged_wishes = self._merge_similar_items(all_wishes, "description")
        
        # Create combined summary
        combined_summary = " | ".join(all_summaries[:3]) if all_summaries else "Analysis completed across multiple batches."
        
        # Determine overall sentiment from counts
        if positive_count + negative_count > 0:
            ratio = positive_count / (positive_count + negative_count)
            if ratio > 0.95:
                sentiment = "Overwhelmingly Positive"
            elif ratio > 0.85:
                sentiment = "Very Positive"
            elif ratio > 0.70:
                sentiment = "Mostly Positive"
            elif ratio > 0.40:
                sentiment = "Mixed"
            elif ratio > 0.20:
                sentiment = "Mostly Negative"
            elif ratio > 0.05:
                sentiment = "Negative"
            else:
                sentiment = "Overwhelmingly Negative"
        else:
            sentiment = "Mixed"
        
        result = AnalysisResult(
            app_id=app_id,
            total_reviews_analyzed=total_analyzed,
            positive_reviews=positive_count,
            negative_reviews=negative_count,
            overall_sentiment=sentiment,
            bugs=[BugReport(**bug) for bug in merged_bugs],
            wishes=[WishItem(**wish) for wish in merged_wishes],
            summary=combined_summary
        )
        
        return result
    
    def _build_batch_prompt(self, reviews: List[str]) -> str:
        """Build a simpler prompt for batch processing."""
        reviews_text = "\n---\n".join([f"Review {i+1}:\n{review}" for i, review in enumerate(reviews)])
        
        return f"""Analyze these Steam game reviews and extract structured information.

Return JSON with this structure:
{{
    "bugs": [
        {{"description": "detailed bug description", "severity": "critical|major|minor", "frequency": <number>}}
    ],
    "wishes": [
        {{"description": "detailed feature request", "priority": "high|medium|low", "frequency": <number>}}
    ],
    "summary": "brief summary (1-2 sentences)"
}}

Guidelines:
- List EVERY unique bug/issue mentioned - do NOT group similar ones
- List EVERY unique feature request - do NOT group similar ones
- Be thorough and detailed

Reviews:
{reviews_text}

Respond ONLY with JSON."""
    
    def _merge_similar_items(self, items: List[Dict], key: str) -> List[Dict]:
        """Merge similar items by combining frequencies."""
        merged = {}
        for item in items:
            # Use first 3 words as key for grouping
            desc = item.get(key, "")
            short_key = " ".join(desc.lower().split()[:4])
            
            if short_key in merged:
                merged[short_key]["frequency"] += item.get("frequency", 1)
            else:
                merged[short_key] = item.copy()
        
        # Sort by frequency descending
        return sorted(merged.values(), key=lambda x: x.get("frequency", 0), reverse=True)


# Singleton instance for dependency injection
_ai_analyzer: Optional[GeminiAIAnalyzer] = None


def get_ai_analyzer() -> GeminiAIAnalyzer:
    """Dependency injection for AI analyzer."""
    global _ai_analyzer
    if _ai_analyzer is None:
        _ai_analyzer = GeminiAIAnalyzer()
    return _ai_analyzer